
package com.mycompany.nexus_certo.apirest.repository;

import com.mycompany.nexus_certo.apirest.model.OrcamentoModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrcamentoRepository extends JpaRepository<OrcamentoModel, Integer>{
    
}
