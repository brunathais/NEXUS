
package com.mycompany.nexus_certo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class NEXUS_certo {
    public static void main(String[] args) {
        SpringApplication.run(NEXUS_certo.class, args);
    }
}
