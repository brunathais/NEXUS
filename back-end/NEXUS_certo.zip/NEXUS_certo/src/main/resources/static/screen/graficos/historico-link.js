document.getElementById('btn-historico').addEventListener('click', () => {
  window.open('historico.html', '_blank');
});
