document.addEventListener('DOMContentLoaded', () => {
    const div = document.getElementById('conteudo');
    div.innerHTML = '<p>Funcionalidade básica carregada.</p>';
});