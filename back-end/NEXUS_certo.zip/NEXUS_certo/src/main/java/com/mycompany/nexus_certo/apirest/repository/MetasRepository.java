package com.mycompany.nexus_certo.apirest.repository;

import com.mycompany.nexus_certo.apirest.model.MetasModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetasRepository extends JpaRepository<MetasModel, Integer>{
    
}
