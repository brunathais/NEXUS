
package com.ska.NEXUS.service;

import com.ska.NEXUS.dto.UsuarioDTO;

public class UsuarioService {
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    public String receberMensagem(UsuarioDTO usuarioDTO){
        
        return usuarioRepository.inserirUsuario(usuarioDTO);

    }
}
