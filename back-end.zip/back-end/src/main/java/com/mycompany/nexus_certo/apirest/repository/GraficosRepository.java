
package com.mycompany.nexus_certo.apirest.repository;

import com.mycompany.nexus_certo.apirest.model.GraficosModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GraficosRepository extends JpaRepository<GraficosModel, Integer>{
    
}
